__all__ = ["Dashboard","Localizer"]

from view_control.Dashboard import Dashboard
from view_control.Localizer import Localizer